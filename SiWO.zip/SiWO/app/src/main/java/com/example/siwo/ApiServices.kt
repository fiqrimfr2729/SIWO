package com.example.siwo


import androidx.annotation.Keep
import com.example.siwo.Response.Dekorasi
import com.example.siwo.Response.Respon
import retrofit2.Call
import retrofit2.http.*

interface ApiServices {

    @FormUrlEncoded
    @POST("login")
    fun login(@Field("username") username: String?,
              @Field("password") password: String?): Call<Respon>

    @Keep
    @GET("dekorasi")
    fun getDekorasi(): Call<ArrayList<Dekorasi>>
}